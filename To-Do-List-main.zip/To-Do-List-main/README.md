1) download zip
2) Open terminal and change directory to "cd /Users/apoorv/Downloads/To-Do-List-main/"
3) run "node app.js"
4) Open Browser and Hit localhost:3000/
